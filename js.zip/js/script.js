// ==========================================================
// Sipho's Plumbing & Maintenance — JavaScript
// Part 3 — Enhancing Functionality and SEO
//
// Contents:
//   1.  Mobile navigation toggle
//   2.  FAQ accordion (services.html)
//   3.  Gallery lightbox (index.html)
//   4.  Dynamic content + search/filter (services.html)
//   5.  Scroll-to-top button
//   6.  Form validation helpers (shared)
//   7.  Enquiry form: validation + processed response (cost/availability)
//   8.  Contact form: validation + compiled email submission
//   9.  Interactive map with multiple locations (contact.html, Leaflet)
//   10. Footer year
// ==========================================================

document.addEventListener('DOMContentLoaded', function () {

    /* ======================================================
       1. MOBILE NAVIGATION TOGGLE
       ====================================================== */
    var navToggle = document.getElementById('nav-toggle');
    var mainNav = document.getElementById('main-nav');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', function () {
            var isOpen = mainNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            navToggle.textContent = isOpen ? '\u2715 Close' : '\u2630 Menu';
        });
    }

    /* ======================================================
       2. FAQ ACCORDION
       Collapses each answer; clicking a question toggles it.
       ====================================================== */
    var faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(function (item) {
        var question = item.querySelector('h3');
        var answer = item.querySelector('p');
        if (!question || !answer) return;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'faq-toggle';
        btn.setAttribute('aria-expanded', 'false');
        btn.innerHTML = question.innerHTML + '<span class="faq-icon" aria-hidden="true">+</span>';

        question.innerHTML = '';
        question.appendChild(btn);

        answer.classList.add('faq-answer');
        answer.hidden = true;

        btn.addEventListener('click', function () {
            var expanded = btn.getAttribute('aria-expanded') === 'true';
            btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            answer.hidden = expanded;
            var icon = btn.querySelector('.faq-icon');
            if (icon) icon.textContent = expanded ? '+' : '\u2212';
        });
    });

    /* ======================================================
       3. GALLERY LIGHTBOX
       Clicking a gallery image opens it larger in an overlay.
       ====================================================== */
    var galleryImages = document.querySelectorAll('.work-gallery img');

    if (galleryImages.length > 0) {
        var lightbox = document.createElement('div');
        lightbox.className = 'lightbox';
        lightbox.setAttribute('role', 'dialog');
        lightbox.setAttribute('aria-modal', 'true');
        lightbox.setAttribute('aria-label', 'Enlarged image');
        lightbox.hidden = true;
        lightbox.innerHTML =
            '<button class="lightbox-close" type="button" aria-label="Close image">\u2715</button>' +
            '<button class="lightbox-prev" type="button" aria-label="Previous image">\u2039</button>' +
            '<img class="lightbox-img" src="" alt="">' +
            '<p class="lightbox-caption"></p>' +
            '<button class="lightbox-next" type="button" aria-label="Next image">\u203A</button>';
        document.body.appendChild(lightbox);

        var lbImg = lightbox.querySelector('.lightbox-img');
        var lbCaption = lightbox.querySelector('.lightbox-caption');
        var currentIndex = 0;

        function showImage(index) {
            if (index < 0) index = galleryImages.length - 1;
            if (index >= galleryImages.length) index = 0;
            currentIndex = index;

            var img = galleryImages[index];
            lbImg.src = img.src;
            lbImg.alt = img.alt;

            var fig = img.closest('figure');
            var figcaption = fig ? fig.querySelector('figcaption') : null;
            lbCaption.textContent = figcaption ? figcaption.textContent : img.alt;
        }

        function openLightbox(index) {
            showImage(index);
            lightbox.hidden = false;
            document.body.classList.add('no-scroll');
            lightbox.querySelector('.lightbox-close').focus();
        }

        function closeLightbox() {
            lightbox.hidden = true;
            document.body.classList.remove('no-scroll');
        }

        galleryImages.forEach(function (img, index) {
            img.classList.add('clickable');
            img.setAttribute('tabindex', '0');
            img.addEventListener('click', function () { openLightbox(index); });
            img.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    openLightbox(index);
                }
            });
        });

        lightbox.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
        lightbox.querySelector('.lightbox-prev').addEventListener('click', function () {
            showImage(currentIndex - 1);
        });
        lightbox.querySelector('.lightbox-next').addEventListener('click', function () {
            showImage(currentIndex + 1);
        });

        lightbox.addEventListener('click', function (e) {
            if (e.target === lightbox) closeLightbox();
        });

        document.addEventListener('keydown', function (e) {
            if (lightbox.hidden) return;
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') showImage(currentIndex - 1);
            if (e.key === 'ArrowRight') showImage(currentIndex + 1);
        });
    }

    /* ======================================================
       4. DYNAMIC CONTENT + SEARCH / FILTER
       Service list is rendered from a data array, then
       filtered live by the search box and category buttons.
       ====================================================== */
    var serviceListEl = document.getElementById('service-list');
    var serviceSearchEl = document.getElementById('service-search');
    var serviceCountEl = document.getElementById('service-count');
    var filterButtons = document.querySelectorAll('.filter-btn');

    var servicesData = [
        { name: 'Burst pipe repair', category: 'plumbing', price: 'From R650', desc: 'Emergency repair of burst or split water pipes, including re-pressurising the line.' },
        { name: 'Leaking tap repair', category: 'plumbing', price: 'From R350', desc: 'Washer, cartridge and mixer repairs for dripping or stiff taps.' },
        { name: 'Blocked drain clearing', category: 'plumbing', price: 'From R550', desc: 'Mechanical clearing of blocked sinks, toilets and outside drains.' },
        { name: 'Water pressure diagnosis', category: 'plumbing', price: 'From R450', desc: 'Tracing and resolving low or inconsistent water pressure.' },
        { name: 'Geyser replacement', category: 'geyser', price: 'From R4 500', desc: 'Supply and installation of a new geyser, including compliance certificate.' },
        { name: 'Geyser element and thermostat', category: 'geyser', price: 'From R900', desc: 'Replacement of failed heating elements and thermostats.' },
        { name: 'Geyser emergency call-out', category: 'geyser', price: 'From R750', desc: 'Same-day attendance for burst, leaking or non-heating geysers.' },
        { name: 'Quarterly inspection plan', category: 'maintenance', price: 'From R1 200/yr', desc: 'Scheduled plumbing inspections to catch problems before they escalate.' },
        { name: 'Preventative maintenance contract', category: 'maintenance', price: 'Quoted per property', desc: 'Tailored maintenance agreement for homes and small commercial properties.' },
        { name: 'Bundled small repairs visit', category: 'maintenance', price: 'From R800', desc: 'Several small jobs handled in one planned visit to save on call-out costs.' }
    ];

    var activeCategory = 'all';

    function renderServices() {
        if (!serviceListEl) return;

        var query = serviceSearchEl ? serviceSearchEl.value.trim().toLowerCase() : '';

        var filtered = servicesData.filter(function (service) {
            var matchesCategory = activeCategory === 'all' || service.category === activeCategory;
            var matchesQuery = query === '' ||
                service.name.toLowerCase().indexOf(query) !== -1 ||
                service.desc.toLowerCase().indexOf(query) !== -1;
            return matchesCategory && matchesQuery;
        });

        serviceListEl.innerHTML = '';

        if (filtered.length === 0) {
            serviceListEl.innerHTML =
                '<li class="no-results">No services match your search. ' +
                '<a href="enquiry.html">Send us an enquiry</a> and we will let you know if we can help.</li>';
        } else {
            filtered.forEach(function (service) {
                var li = document.createElement('li');
                li.className = 'service-item';
                li.innerHTML =
                    '<div class="service-item-head">' +
                        '<h3>' + service.name + '</h3>' +
                        '<span class="service-price">' + service.price + '</span>' +
                    '</div>' +
                    '<p>' + service.desc + '</p>' +
                    '<span class="service-tag">' + service.category + '</span>';
                serviceListEl.appendChild(li);
            });
        }

        if (serviceCountEl) {
            serviceCountEl.textContent = filtered.length + ' of ' + servicesData.length + ' services shown';
        }
    }

    if (serviceListEl) {
        renderServices();

        if (serviceSearchEl) {
            serviceSearchEl.addEventListener('input', renderServices);
        }

        filterButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                filterButtons.forEach(function (b) {
                    b.classList.remove('active');
                    b.setAttribute('aria-pressed', 'false');
                });
                btn.classList.add('active');
                btn.setAttribute('aria-pressed', 'true');
                activeCategory = btn.getAttribute('data-category');
                renderServices();
            });
        });
    }

    /* ======================================================
       5. SCROLL-TO-TOP BUTTON
       ====================================================== */
    var topBtn = document.createElement('button');
    topBtn.type = 'button';
    topBtn.className = 'scroll-top';
    topBtn.setAttribute('aria-label', 'Scroll back to top');
    topBtn.innerHTML = '\u2191';
    document.body.appendChild(topBtn);

    window.addEventListener('scroll', function () {
        if (window.scrollY > 400) {
            topBtn.classList.add('visible');
        } else {
            topBtn.classList.remove('visible');
        }
    });

    topBtn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    /* ======================================================
       6. SHARED FORM VALIDATION HELPERS
       ====================================================== */
    function showError(field, message) {
        clearError(field);
        field.classList.add('invalid');
        field.setAttribute('aria-invalid', 'true');

        var error = document.createElement('span');
        error.className = 'field-error';
        error.setAttribute('role', 'alert');
        error.textContent = message;
        field.insertAdjacentElement('afterend', error);
    }

    function clearError(field) {
        field.classList.remove('invalid');
        field.removeAttribute('aria-invalid');
        var next = field.nextElementSibling;
        if (next && next.classList.contains('field-error')) {
            next.remove();
        }
    }

    function validateRequired(field, message) {
        if (field.value.trim() === '') {
            showError(field, message);
            return false;
        }
        clearError(field);
        return true;
    }

    function validateEmail(field) {
        var pattern = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;
        if (field.value.trim() === '') {
            showError(field, 'Please enter your email address.');
            return false;
        }
        if (!pattern.test(field.value.trim())) {
            showError(field, 'Please enter a valid email address, e.g. name@example.com.');
            return false;
        }
        clearError(field);
        return true;
    }

    function validatePhone(field) {
        // Accepts SA formats: 0111234567, 011 123 4567, +27 11 123 4567
        var cleaned = field.value.replace(/[\s()-]/g, '');
        var pattern = /^(\+27|0)[1-8][0-9]{8}$/;
        if (cleaned === '') {
            showError(field, 'Please enter a contact number.');
            return false;
        }
        if (!pattern.test(cleaned)) {
            showError(field, 'Please enter a valid South African number, e.g. 011 123 4567 or +27 11 123 4567.');
            return false;
        }
        clearError(field);
        return true;
    }

    function validateMinLength(field, min, message) {
        if (field.value.trim().length < min) {
            showError(field, message);
            return false;
        }
        clearError(field);
        return true;
    }

    function validateSelect(field, message) {
        if (field.value === '') {
            showError(field, message);
            return false;
        }
        clearError(field);
        return true;
    }

    /* ======================================================
       7. ENQUIRY FORM
       Validates input, then processes it and presents a
       response about cost and availability.
       ====================================================== */
    var quoteForm = document.getElementById('quote-form');

    if (quoteForm) {
        var priceBands = {
            'plumbing-repair': { label: 'Plumbing Repair', from: 350, to: 1500 },
            'geyser':          { label: 'Geyser Installation / Repair', from: 900, to: 6500 },
            'maintenance':     { label: 'General Maintenance', from: 800, to: 2500 },
            'other':           { label: 'Other', from: 400, to: 2000 }
        };

        var availability = {
            'emergency':  'We prioritise emergencies \u2014 expect a call back within the hour and same-day attendance.',
            'this-week':  'We currently have availability this week and will confirm a time slot when we call.',
            'flexible':   'We will call you to arrange a convenient time, usually within 2\u20133 working days.'
        };

        var callOut = {
            'emergency': 'An after-hours/emergency call-out fee may apply, and will be quoted before we dispatch.',
            'this-week': 'The standard call-out fee is waived if you proceed with the repair.',
            'flexible':  'The standard call-out fee is waived if you proceed with the repair.'
        };

        quoteForm.addEventListener('submit', function (e) {
            e.preventDefault();

            var name = document.getElementById('full-name');
            var email = document.getElementById('email');
            var phone = document.getElementById('phone');
            var serviceType = document.getElementById('service-type');
            var urgency = document.getElementById('urgency');
            var address = document.getElementById('address');
            var message = document.getElementById('message');

            // Run every check (no short-circuit) so all errors show at once
            var checks = [
                validateRequired(name, 'Please enter your full name.'),
                validateEmail(email),
                validatePhone(phone),
                validateSelect(serviceType, 'Please select the type of service you need.'),
                validateSelect(urgency, 'Please tell us how urgent this is.'),
                validateRequired(address, 'Please enter the property address or suburb.'),
                validateMinLength(message, 15, 'Please give us a bit more detail (at least 15 characters).')
            ];

            var isValid = checks.every(function (ok) { return ok; });

            if (!isValid) {
                var firstInvalid = quoteForm.querySelector('.invalid');
                if (firstInvalid) firstInvalid.focus();
                return;
            }

            // --- Process the validated input into a response ---
            var band = priceBands[serviceType.value] || priceBands['other'];
            var reference = 'SP-' + Date.now().toString().slice(-6);
            var firstName = name.value.trim().split(' ')[0];
            var phoneValue = phone.value.trim();
            var emailValue = email.value.trim();
            var addressValue = address.value.trim();

            var response = document.getElementById('quote-response');
            if (!response) {
                response = document.createElement('div');
                response.id = 'quote-response';
                response.className = 'form-response';
                response.setAttribute('role', 'status');
                quoteForm.insertAdjacentElement('afterend', response);
            }

            response.innerHTML =
                '<h3>Thank you, ' + firstName + ' \u2014 your request is in.</h3>' +
                '<p><strong>Reference:</strong> ' + reference + '</p>' +
                '<p><strong>Service:</strong> ' + band.label + '</p>' +
                '<p><strong>Estimated cost:</strong> R' + band.from + ' \u2013 R' + band.to +
                    '. This is an indicative range only; the final price is confirmed on site before any work begins.</p>' +
                '<p><strong>Availability:</strong> ' + (availability[urgency.value] || '') + '</p>' +
                '<p><strong>Call-out fee:</strong> ' + (callOut[urgency.value] || '') + '</p>' +
                '<p>We will contact you on <strong>' + phoneValue + '</strong> or at <strong>' +
                    emailValue + '</strong> regarding the property at ' + addressValue + '.</p>';

            response.hidden = false;
            quoteForm.reset();
            response.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });

        // Clear a field's error as soon as the user starts fixing it
        quoteForm.querySelectorAll('input, select, textarea').forEach(function (field) {
            field.addEventListener('input', function () { clearError(field); });
            field.addEventListener('change', function () { clearError(field); });
        });
    }

    /* ======================================================
       8. CONTACT FORM
       Validates input, compiles it into an email body, and
       lets the user send it to the organisation.
       ====================================================== */
    var contactForm = document.getElementById('contact-form');

    if (contactForm) {
        var RECIPIENT = 'info@siphosplumbing.co.za';

        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();

            var name = document.getElementById('contact-name');
            var email = document.getElementById('contact-email');
            var reason = document.getElementById('contact-reason');
            var message = document.getElementById('contact-message');

            var checks = [
                validateRequired(name, 'Please enter your full name.'),
                validateEmail(email),
                validateSelect(reason, 'Please select a reason for contacting us.'),
                validateMinLength(message, 20, 'Please enter a message of at least 20 characters.')
            ];

            var isValid = checks.every(function (ok) { return ok; });

            if (!isValid) {
                var firstInvalid = contactForm.querySelector('.invalid');
                if (firstInvalid) firstInvalid.focus();
                return;
            }

            // --- Compile the validated input into an email ---
            var reasonLabel = reason.options[reason.selectedIndex].text;
            var subject = 'Website enquiry (' + reasonLabel + ') \u2014 ' + name.value.trim();
            var body =
                'Name: ' + name.value.trim() + '\n' +
                'Email: ' + email.value.trim() + '\n' +
                'Reason for contact: ' + reasonLabel + '\n\n' +
                'Message:\n' + message.value.trim() + '\n\n' +
                '\u2014 Sent from the Sipho\'s Plumbing & Maintenance website';

            var mailtoLink = 'mailto:' + RECIPIENT +
                '?subject=' + encodeURIComponent(subject) +
                '&body=' + encodeURIComponent(body);

            var response = document.getElementById('contact-response');
            if (!response) {
                response = document.createElement('div');
                response.id = 'contact-response';
                response.className = 'form-response';
                response.setAttribute('role', 'status');
                contactForm.insertAdjacentElement('afterend', response);
            }

            var preview = document.createElement('pre');
            preview.className = 'email-preview';
            preview.textContent =
                'To: ' + RECIPIENT + '\n' +
                'Subject: ' + subject + '\n\n' +
                body;

            response.innerHTML =
                '<h3>Your message is ready to send</h3>' +
                '<p>We have compiled your message below. Click the button to open it in your email ' +
                    'program and send it to ' + RECIPIENT + '.</p>';
            response.appendChild(preview);

            var sendBtn = document.createElement('a');
            sendBtn.className = 'btn-primary';
            sendBtn.id = 'send-email-btn';
            sendBtn.href = mailtoLink;
            sendBtn.textContent = 'Send Email';
            response.appendChild(sendBtn);

            response.hidden = false;
            response.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });

        contactForm.querySelectorAll('input, select, textarea').forEach(function (field) {
            field.addEventListener('input', function () { clearError(field); });
            field.addEventListener('change', function () { clearError(field); });
        });
    }

    /* ======================================================
       9. INTERACTIVE MAP (Leaflet)
       Pannable, zoomable map showing both service locations
       as clickable markers with popups.
       ====================================================== */
    var mapEl = document.getElementById('interactive-map');

    if (mapEl && typeof L !== 'undefined') {
        var locations = [
            {
                name: 'Main Workshop',
                address: '12 Bramley Road, Bramley, Johannesburg, 2018',
                hours: 'Mon\u2013Fri: 07:00\u201317:00 | Sat: 08:00\u201313:00',
                lat: -26.1281,
                lng: 28.0876
            },
            {
                name: 'Service Area \u2014 Northern Suburbs',
                address: 'Sandton, Bryanston, Rivonia and surrounds',
                hours: 'Emergency call-outs available daily',
                lat: -26.1076,
                lng: 28.0567
            }
        ];

        var map = L.map('interactive-map').setView([-26.118, 28.072], 12);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var bounds = [];

        locations.forEach(function (loc) {
            var marker = L.marker([loc.lat, loc.lng]).addTo(map);
            marker.bindPopup(
                '<strong>' + loc.name + '</strong><br>' +
                loc.address + '<br>' +
                '<em>' + loc.hours + '</em>'
            );
            bounds.push([loc.lat, loc.lng]);
        });

        map.fitBounds(bounds, { padding: [50, 50] });
    }

    /* ======================================================
       10. FOOTER YEAR (keeps the copyright current)
       ====================================================== */
    document.querySelectorAll('.current-year').forEach(function (el) {
        el.textContent = new Date().getFullYear();
    });

});
